% figure('Renderer', 'painters', 'Position', [10 10 500 200])

array_sizes = size(INV_E);
nrow = array_sizes(1);

figure(1)
%clf

% epss-q plot
color = 'b';
leyenda = 'Dr = 77%';
subplot(1,2,1)

xx=INV_E(1:nrow,2);
yy=INV_S(1:nrow,2);
plot(xx,yy,color)
xlabel('Deformación de corte')
ylabel('Desviador de tensiones q [kPa]')
grid on
hold on

subplot(1,2,2)
xx=INV_E(1:nrow,2);
yy=INV_E(1:nrow,1);
plot(xx,yy,color)
legend('Dr = 90%','Dr = 77%','Dr = 62%')
ylabel('Deformación Volumétrica')
xlabel('Deformación de corte')
grid on
hold on
% eps_v-p plot
