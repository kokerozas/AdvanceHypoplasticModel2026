function F = f_hyp(y,S,E,V,parms)

% F_EP: computes RHS of the evolution ODE for plastic processes
%

M=[1,  0,  0,  0,  0,  0
   0,  1,  0,  0,  0,  0
   0,  0,  1,  0,  0,  0
   0,  0,  0,  2,  0,  0
   0,  0,  0,  0,  2,  0
   0,  0,  0,  0,  0,  2];

M2=[1,  0,  0,  0,    0,    0
   0,  1,  0,  0,    0,    0
   0,  0,  1,  0,    0,    0 
   0,  0,  0,  0.5,  0,    0
   0,  0,  0,  0,    0.5,  0
   0,  0,  0,  0,    0,    0.5];

mR	   	= parms(12);
ny 		= max(size(y));
qint 		= y(13:ny,1);
istrain		= qint(2:7,1);

ny = max(size(y));
F = zeros(ny,1);

[Lep,Nep,Hep] = hyp_stif(y,parms);
Hdel = zeros(6,6);

%% compute A matrix and solve for deps

Maux=Lep*mR;
A    = S*Maux+E;
depsaux = A\V;
[Mep,Hdel]=M_istr(Lep,Nep,depsaux,istrain,parms);

A    = S*Mep+E;
depsMNR = A\V;
depsinit = depsMNR;
sigpresc = Mep*depsMNR;
[Mep,Hdel]=M_istr(Lep,Nep,depsMNR,istrain,parms);

%% Modified Newton-Raphson interations for correction of deps
stresscontrol=zeros(6,1);
for i = 1:6
  for j = 1:6
    if  (S(i,j) > 0)
      stresscontrol(j)=1;
    end
  end
end

isstresscont=sqrt(stresscontrol'*M*stresscontrol);

if isstresscont > 0
  tol_mnriter  = parms(3);
  itererror=1000;
  
  while itererror > tol_mnriter
  
        sigest= Mep*depsMNR;
        unbalsig=sigpresc-sigest;
 
        for i = 1:6
	  if  (stresscontrol(i) == 0)
	    depsMNR(i)=depsinit(i);
	    unbalsig(i)=0;
	  end
        end

        depsMNR=depsMNR + Mep\unbalsig;
        itererror=sqrt(unbalsig'*M*unbalsig);

        [Mep,Hdel]=M_istr(Lep,Nep,depsMNR,istrain,parms);
  end
end
%% F vector

F(1:6,1)   = depsMNR;
F(7:12,1)  = Mep*depsMNR;
de=Hep'*depsMNR;
distrain=Hdel'*depsMNR;
F(13,1) = de;
F(14:ny,1) = distrain;
