function y = fitnessfunction(x)
input_data;
init_state;
exy = [0   0.005 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.11 0.12 0.13 0.14 0.15 0.16 0.17 0.18 0.19 0.20];
dr90= [0   230   345  440  505  530  540  545  535  525  500  475 455  435  415  395  380  365  355  345  340  337];
dr77= [0   160   295  370  420  445  455  460  458  450  440  423 410  393  380  365  355  345  337  327  323  320];
dr62= [0   150   235  300  340  365  380  390  395  392  385  380 372  363  357  349  340  333  326  322  320  318];
dr17= [0   110   160  207  240  260  275  285  293  300  305  308 310  310  310  310  310  310  310  310  310  310];
ev90= [0   0.0023 0.0019 -0.0028  -0.0095 -0.018 -0.027 -0.036 -0.042 -0.05 -0.0585 -0.0645 -0.0711 -0.0755 -0.0790 -0.0810 -0.0835 -0.085 -0.086 -0.089 -0.090 -0.092];


eps0 = [0.9683 0.7361 0.6587 0.5916];
rel  = [0.17 0.62 0.77 0.90];

    for ik = 1:4
        
%                 y0(end-6) = eps0(ik);
                e_relative= x(4) - rel(ik)*(x(4)-x(6)) ;
                y0(end-6) = e_relative;
                parms(11) = x(1);     
                parms(10) = x(2); 
                parms(4)  = x(3);
                parms(8)  = x(4);
                parms(9)  = x(5);
                parms(7)  = x(6);
%                 parms(5)  = x(7);
%                 parms(6)  = x(8);
                [~,Es,INV_S,INV_E,~] = updateModel(y0,parms,nspb,path_info);
                SS(:,ik) = INV_S(:,2);
                
    end

    SS_int = interp1(Es(:,3),SS,exy');
    y_real = [dr17' dr62' dr77' dr90'];
    y_tr1  = SS_int(1:9,:) - y_real(1:9,:);
    y_tr2  = SS_int(10:end-1,:) - y_real(10:end-1,:);
    y1     = norm(y_tr1(:,1) + y_tr1(:,2) + y_tr1(:,3))/norm(SS_int(1:9,:));
    y2     = norm(y_tr2(:,1) + y_tr2(:,2) + y_tr2(:,3))/norm(SS_int(10:end-1,:));
    y = y1*0.5 + y2*0.5;
%     y(1)     = norm(y_tr1(:,1) + y_tr1(:,2) + y_tr1(:,3))/norm(SS_int(1:9,:));
%     y(2)     = norm(y_tr2(:,1) + y_tr2(:,2) + y_tr2(:,3))/norm(SS_int(10:end,:));
%     y(1) = norm(SS_int(:,1)-dr17')/norm(SS_int(:,1));
%     y(2) = norm(SS_int(:,2)-dr62')/norm(SS_int(:,2));
%     y(3) = norm(SS_int(:,3)-dr77')/norm(SS_int(:,3));
%     y(4) = norm(SS_int(:,4)-dr90')/norm(SS_int(:,4));
%     y = sum(y);
    
%     y = y1*0.5+y2*0.5;
    figure(1)
    subplot(1,2,1)
    plot(Es(:,3),SS(:,1),'r'); hold on;
    plot(Es(:,3),SS(:,2),'b')
    plot(Es(:,3),SS(:,3),'g')
    plot(Es(:,3),SS(:,4),'m')
    plot(exy,dr90,'mo');
    plot(exy,dr77,'go');
    plot(exy,dr62,'bo');
    plot(exy,dr17,'ro'); 
    hold off;
    subplot(1,2,2)
    plot(exy,ev90,'mo'); hold on
    plot(Es(:,3),INV_E(:,1)); 
    hold off;
    pause(0.1)
    x
end