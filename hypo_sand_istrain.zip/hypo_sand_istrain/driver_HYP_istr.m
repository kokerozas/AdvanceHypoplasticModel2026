% DRIVER_EP - Octave version
%
% Constitutive driver for integrating elastoplastic constitutive
% equations using the algorithm proposed by
% Bardet & Choucair (1991), IJNAMG
%
% written by C. Tamagnini - Jan. 2012
%



disp('===========================================')
disp('                DRIVER HYP                 ')
disp('===========================================')
disp('                                           ')
disp('     constitutive driver for numerical     ')
disp('        integration of hypoplastic         ')
disp('           constitutive equations          ')
disp('       using the algorithm proposed by     ')
disp('      Bardet & Choucair (1991), IJNAMG     ')
disp('                                           ')
disp('           written by C. Tamagnini         ')
disp('      modifications for hypoplasticity     ')
disp('                by D. Masin                ')
disp('                                           ')
disp('===========================================')
disp('                                           ')
disp('     ALERT Olek Zienkiewicz School 2012    ')
disp('      "Constitutive Modeling of Soils"     ')
disp('             Dresden, sept. 2012           ')
disp('                                           ')
disp('===========================================')



%% input data and initial material state

input_data;
init_state;

%% 
%% call integration procedure
% clc; clear
input_data;
init_state;

[SS,EE,INV_S,INV_E,HARD] = updateModel(y0,parms,nspb,path_info);
subplot(1,2,1); hold on;
plot(EE(:,3),SS(:,3)-SS(:,1));
% plot(e_jorge_035,q_jorge_035)
plot(EE(:,6),SS(:,6));
subplot(1,2,2); hold on;
plot(INV_S(:,1),SS(:,3)-SS(:,1));

% load = def035(1:500)/100;
% x = linspace(1,length(load),600);
% load_new = interp1(1:length(load),load,x);

% [SS,EE,INV_S,INV_E,HARD] = updateModel2(y0,parms,nspb,path_info,load);

% figure(1); hold on;
% plot(EE(:,3),SS(:,3)-SS(:,1));
% plot(INV_S(:,1),SS(:,3)-SS(:,1));
% plot(def035/100,-q035)
% figure(2); hold on;
% plot(INV_S(:,1),INV_S(:,2).*INV_S(:,3)/2)
% figure(3)
% plot(-1*(INV_S(:,1)-100)/100); hold on;
% plot(ru035,'.-b');grid on

% xyplot_vmh; hold on;

% exy = [0   0.005 0.01  0.02     0.03     0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.11 0.12 0.13 0.14 0.15 0.16 0.17 0.18 0.19 0.20];
% dr90= [0   230   345  440  505  530  540  545  535  525  500  475 455  435  415  395  380  365  355  345  340  337];
% ev90= [0   0.0023 0.0019 -0.0028  -0.0095 -0.018 -0.027 -0.036 -0.042 -0.05 -0.0585 -0.0645 -0.0711 -0.0755 -0.0790 -0.0810 -0.0835 -0.085 -0.086 -0.089 -0.090 -0.092];
% 
% dr77= [0   160   295  370  420  445  455  460  458  450  440  423 410  393  380  365  355  345  337  327  323  320];
% dr62= [0   150   235  300  340  365  380  390  395  392  385  380 372  363  357  349  340  333  326  322  320  318];
% dr17= [0   110   160  207  240  260  275  285  293  300  305  308 310  310  310  310  310  310  310  310  310  310];
% 
% beta  = [linspace(0.85,2,5)];
% alpha = [linspace(0.08,0.11,5)];
% A = combvec(beta,alpha)';
% eps0 = [0.9683 0.7361 0.6587 0.5916];
% 
% %     y0(end-6) = eps0(ik);
% 
% A = [1.0486,0.1075,36.0093,.8325, 1.1142, 0.5526];
% 
rel  = [0.17 0.62 0.77 0.90];
% 
% data17 = xlsread('D:\Thesis\Datos-Experimentales\Triaxial arena B�o B�o (KIT,2012).xls','Datos (DR=17%)');
% data62 = xlsread('D:\Thesis\Datos-Experimentales\Triaxial arena B�o B�o (KIT,2012).xls','Datos (DR=62%)');
% data77 = xlsread('D:\Thesis\Datos-Experimentales\Triaxial arena B�o B�o (KIT,2012).xls','Datos (DR=77%)');
% data90 = xlsread('D:\Thesis\Datos-Experimentales\Triaxial arena B�o B�o (KIT,2012).xls','Datos (DR=90%)');
% % 
%     for ik = 1:4
%                 y0(13) = ei0 - rel(ik)*(ei0-ed0);
%                 [SS,EE,INV_S,INV_E,HARD] = updateModel(y0,parms,nspb,path_info);
% 
%                 subplot(1,2,1)
%                 plot(EE(:,3),INV_S(:,2),'r'); hold on;
%                 plot(data17(:,1)/100,data17(:,8)*2,'b-');
%                 plot(data62(:,1)/100,data62(:,8)*2,'b-');
%                 plot(data77(:,1)/100,data77(:,8)*2,'b-');
%                 plot(data90(:,1)/100,data90(:,8)*2,'b-');
%                 subplot(1,2,2)
%                 plot(EE(:,3),INV_E(:,1),'m'); hold on;
%                 plot(data17(:,1)/100,data17(:,2)/100,'b-'); hold on;
%                 plot(data62(:,1)/100,data62(:,2)/100,'b-');
%                 plot(data77(:,1)/100,data77(:,2)/100,'b-');
%                 plot(data90(:,1)/100,data90(:,2)/100,'b-');
% %                 plot(EE(:,3),INV_E(:,1))
%                 pause(0.01)
%     end


% TAU17 = interp1(data17(1:end-1,1)/100,data17(1:end-1,8)*2,EE(:,3));
% TAU62 = interp1(data62(1:end-1,1)/100,data62(1:end-1,8)*2,EE(:,3));
% TAU77 = interp1(data77(1:end-1,1)/100,data77(1:end-1,8)*2,EE(:,3));
% TAU90 = interp1(data90(1:end-1,1)/100,data90(1:end-1,8)*2,EE(:,3));
% norm(INV_S(1:end-7,2)-TAU62(1:end-7))/norm(TAU62(1:end-7))
% figure()
% plot(EE(:,3) , TAU62)
% ObjFun = @(x) fitnessfunction(x);
% [x , fval] = fminsearch(ObjFun,[1.0486 0.1075 36.0093 0.8325 1.1142 0.5526]);
% [x , fval] = fmincon(ObjFun,[1.1 0.1026 36 0.9106 1.0911 0.5403],[],[],[],[],[0.9 0.06 35 0.80 1.0 0.52],[2 0.2 37 0.92 1.2 0.56]);


%% call integration procedure
% clc;clear
% input_data;
% init_state;
% mr = 0.55;
% X  = 3;
% Br = 0.18;
% A = combvec(mr,X,Br)';
% sigv = [25 50 75 100 125 150 175 200 225 250 275 300 325 350 375 400];
% k0   = 1-sind(43);
% for j = 1:length(sigv)
%     y0(7:9) = [sigv(j) k0*sigv(j) k0*sigv(j)];
%     for ik = 1:size(A,1)
%         parms(12) = 4.6;
%         parms(13) = 4.6*A(ik,1);
%         parms(end-1)= A(ik,3);
%         parms(end)= A(ik,2);
%     [SS,EE,INV_S,INV_E,HARD] = updateModel(y0,parms,nspb,path_info);
% 
%     % xyplot_vmh; hold on;
%     G = [0];
%         for i = 1:max(size(INV_S))-1
%             G(i+1,1) = (SS(i+1,6)-SS(i,6))/(EE(i+1,6)-EE(i,6));
% %             G(i+1,1) = (INV_S(i+1,2)-INV_S(i,2))/(INV_E(i+1,2)-INV_E(i,2));
%         end
%     g0(j,ik) = max(G);
%     figure(3)
%     semilogx((INV_E(:,2)),G);hold on;
%     pause(0.001)
%     end
%     clf
% end

% plot(sigv,g0); hold on ;
% plot([25 50 100 200 400],[63000 72000 80000 110000 120000],'ro')
% plot([25 50 100 200 400],[50000 56000 71000 89000 108000],'bo')

%% output section: writes results to various files and plot diagrams
input_data;
init_state;
[SS,EE,INV_S,INV_E,HARD] = updateModel(y0,parms,nspb,path_info);

% save inv_s.txt INV_S -ascii;
% save inv_e.txt INV_E -ascii;
% save stresses.txt SS -ascii;
% save strains.txt EE -ascii;
% save hard.txt HARD -ascii;

% xyplot_vmh; hold on;
% G = [0];
% for i = 1:max(size(INV_S))-1
%     G(i+1,1) = (INV_S(i+1,2)-INV_S(i,2))/(INV_E(i+1,2)-INV_E(i,2));
% end
% 
% figure(3)
% semilogx((INV_E(:,2)),G);hold on;legend()
% % figure('Renderer', 'painters', 'Position', [10 10 300 200])

semilogx((SS(:,3)),HARD(:,1),'b','Linewidth',1.1);hold on;legend()
eppps = [0.91 0.906 0.9 0.892 0.882 0.866 0.847 0.849 0.853 0.856 0.859 0.858 0.8565 0.8515 0.843];
vff =   [12.5 25    50  100   200   400   800   400 200 100 50 100 200 400 800];
semilogx(vff,eppps,'ro'); hold on
% set(gca,'Fontname','Calisto MT')
legend({'Simulaci�n','Datos Experimentales'})
legend({'Element test','Experimental data'})
xlabel('log(\sigma) (kPa)')
ylabel('e')
grid on
ecrit = 0.921;
e = ecrit*exp(-(3*vff*(1-0.6666*sind(37.5))/(hs*0.98)).^(nparam*0.98));
semilogx(vff,e,'s')


% figure(3)
% plot(EE(:,3),SS(:,3));hold on;legend()
% plot(asind((SS(:,3) - SS(:,1))./ ( SS(:,3) + SS(:,1) )));

%2.5369e+04
%2.6744e+04

% datos = xlsread('D:\Thesis\Prueba_Yieldsurf.xlsx');
% figure(2) ; subplot(1,2,1)
% plot(-datos(:,1),datos(:,2))
% figure(2) ; subplot(1,2,2)
% plot(-datos(:,3),-datos(:,4))