function [Lep,Nep,Hep] = hyp_stif(y,parms)

% HYP_STIF: computes hypoplastic tensors L and N
%

M=[1,  0,  0,  0,  0,  0
   0,  1,  0,  0,  0,  0
   0,  0,  1,  0,  0,  0
   0,  0,  0,  2,  0,  0
   0,  0,  0,  0,  2,  0
   0,  0,  0,  0,  0,  2];

I=[1,  0,  0,  0,     0,     0
   0,  1,  0,  0,     0,     0
   0,  0,  1,  0,     0,     0 
   0,  0,  0,  0.5,   0,     0
   0,  0,  0,  0,     0.5,   0
   0,  0,  0,  0,     0,   0.5];

kron_delta=[1,  1,  1,  0,  0,  0];

ny = max(size(y));
sig = y(7:12,1);
qint = y(13:ny,1);

e=qint(1);
[p,qdev,z] = inv_s(sig);

T=sig;
T_str=T/(3*p);
T_star=sig-p*kron_delta';
T_str_star=T_str-kron_delta'/3;

TT_str=stress_mult(T_str,T_str);
TT=stress_mult(T_str_star,T_str_star);
TTT=stress_mult(TT,T_str_star);

Tstarnorm = sqrt(T_star'*M*T_star);
Tstrstarnorm = sqrt(T_str_star'*M*T_str_star);

phic     	= parms(4)/180*3.14159265358979;
hs       	= parms(5);
nparam     	= parms(6);
ed0 		= parms(7);
ec0	   	= parms(8);
ei0	   	= parms(9);
alpha	   	= parms(10);
beta	   	= parms(11);

tanpsi=sqrt(3.)*Tstrstarnorm;
TTtrace=stress_trace(TT);
if stress_trace(TT)==0
  TTtrace=0.0000000000000001;
end
cos3theta=-sqrt(6.)*stress_trace(TTT)/(TTtrace^1.5);
F=sqrt((tanpsi*tanpsi/8)+((2-tanpsi*tanpsi)/(2+sqrt(2.)*tanpsi*cos3theta)))-(tanpsi/(2*sqrt(2.)));
a=sqrt(3.)*(3-sin(phic))/(2*sqrt(2.)*sin(phic));

expe=-1*(3*p/hs)^nparam;

ei=ei0*exp(expe);
ec=ec0*exp(expe);
ed=ed0*exp(expe);

smalldiff=0.0001;
re=(e-ed)/(ec-ed);
fd=re^alpha;
if e<=(1+smalldiff)*ed
  fd=0.0001;
  disp('e lower than ed');
end


fs=(hs/nparam)*(ei/e)^beta*((1+ei)/ei)*(3*p/hs)^(1-nparam)/(3 + a*a - a*sqrt(3.)*((ei0-ed0)/(ec0-ed0))^alpha);


% fd = ((-(ec0-e)/(ec0-ed0))+1)^alpha;

% fd = (ec-e)/(ec-ed)*(0.7-1)+1;

% ecrit= exp(-0.01*(p/101.25)^0.1);
% fd = (e/ec)^alpha;

Lep=fs*(F*F*I + a*a*T_str*T_str')/stress_trace(TT_str);
Nep=fs*fd*a*F*(T_str+T_str_star)/stress_trace(TT_str);



Hep = zeros(6,1);
Hep(1:3) = -(1+e);
