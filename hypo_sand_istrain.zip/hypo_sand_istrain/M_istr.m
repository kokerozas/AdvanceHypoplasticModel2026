function [Mep,Hdel] = M_istr(Lep,Nep,deps,istrain,parms)

% computes matrix M of the intergranular strain concept by Niemunis and Herle (1997)

M2=[1,  0,  0,  0,    0,    0
   0,  1,  0,  0,    0,    0
   0,  0,  1,  0,    0,    0 
   0,  0,  0,  0.5,  0,    0
   0,  0,  0,  0,    0.5,  0
   0,  0,  0,  0,    0,    0.5];

I=[1,  0,  0,  0,  0,  0
   0,  1,  0,  0,  0,  0
   0,  0,  1,  0,  0,  0
   0,  0,  0,  1,  0,  0
   0,  0,  0,  0,  1,  0
   0,  0,  0,  0,  0,  1];

mR= parms(12);
mT= parms(13);
Rparam= parms(14);
betar= parms(15);
chi= parms(16);
   
istrain_norm=sqrt(istrain'*M2*istrain);
TINY=1.e-20;
istrain_dir=zeros(6,1);

if  (istrain_norm>TINY)
     istrain_dir=istrain/istrain_norm;
end

istraindir_D=istrain_dir'*M2*deps;
rho=istrain_norm/Rparam;

LijmnSmn=Lep*istrain_dir;
LijmnSmnSkl=LijmnSmn*istrain_dir';
NijSkl=Nep*istrain_dir';

Mep=(mT*rho^chi+mR*(1-rho^chi))*Lep;

if(istraindir_D>0) 
  Mep=Mep+(1-mT)*rho^chi*LijmnSmnSkl-rho^chi*NijSkl;
  Hdel=I-rho^betar*M2*istrain_dir*istrain_dir';
else
  Mep=Mep+(mR-mT)*rho^chi*LijmnSmnSkl;
  Hdel=I;
end
