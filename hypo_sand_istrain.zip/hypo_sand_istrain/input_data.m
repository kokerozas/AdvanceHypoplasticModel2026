% INPUT_DATA: input material constants and store them in vector parms
%             set loading path info
%
% nspb          = no. of stress path branches;
% icode(1:nspb) = vector of path type codes (one for each branch)
% nstep(1:nspb) = vector of step numbers (one for each branch)
% DX(1:nspb)    = vector of total "load" increment for each branch
%
% loading path codes
%
% 1. strain controlled undrained TX compression (axis direction: x_3)
% 2. strain controlled ED compression (axis direction: x_3)
% 3. stress controlled drained TX compression (axis direction: x_3)
% 4. mixed control drained TX compression
% 5. mixed control ED compression
% 6. mixed control plane strain compression
% 7. strain controlled undrained simple shear
% 8. stress (mixed) controlled simple shear

%% material parameters
% 1.0486 0.1075 36.0093 0.8325 1.1142 0.5526
phic     	= 36.0093;
hs       	= 3.4156e5;
nparam     	= 0.4564;
ed0 		= 0.5526; % 0.54
ec0	     	= 0.85;
ei0	   	    = 1.05;
alpha	   	= 0.09;
beta	   	= 1.2;

mR = 4.6*.5;
mT = 0.55*mR;
Rparam = 5.e-5*2; % *8
betar = 0.15; % 0.18
chi = 1.5; % 3

max_ksub 	= 1000;       % max no. of substeps allowed
err_tol  	= 1.0e-4;     % normalized error tolerance for adaptive integration  
tol_mnriter	= 1.0e-10;     % tolerance on Modified Newton Raphson estimation of deps

parms=[max_ksub;
       err_tol;
       tol_mnriter;
       phic;
       hs;
       nparam;
       ed0;
       ec0;
       ei0;
       alpha;
       beta;
       mR;
       mT;
       Rparam;
       betar;
       chi];

%% type and characteristics of loading path

nspb=3;

% icode=[5,5,5];
icode=[5]*ones(1,nspb);%[3,3,3,3,3];
nstep=[500]*ones(1,nspb)%[500,500,500,500,500];
DX=[787.5,-750,750];
% DX=[30,-30*2,30*2];
% DX= 0.25*[1 2*ones(1,nspb-1).*(-1).^(1:nspb-1)];
% DX= [0.0006 -0.002 0.004 -0.06 0.038 -0.07];

path_info = [icode;
             nstep
             DX];
